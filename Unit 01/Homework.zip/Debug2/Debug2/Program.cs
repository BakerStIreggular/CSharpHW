﻿using static System.Console;
class DebugOne2
{
    static void Main()
    {
        //added a closing " after Sqaure
        WriteLine("This program displays a square");
        //corrected the spelling of WriteLine
        WriteLine("&&&&&&&&&&");
        //corrected the spelling of WriteLine
        WriteLine("&        &");
        //added an opening " 
        //added spaced so lined up properly
        WriteLine("&        &");
        //added an opening "
        WriteLine("&        &");
        //added an opening "
        //deleted space at the end
        WriteLine("&&&&&&&&&&");

    }
    //added a closing curly bracket
}

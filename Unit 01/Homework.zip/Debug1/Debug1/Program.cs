﻿using static System.Console;
class DebugOne1
{
    static void Main()
    {
        //Replaced the lower-case l with an Upper-case L
        WriteLine("This program displays some keyboard punctuation");
        WriteLine("!   exclamation point");
        //added a ; after the closing )
        WriteLine("@   at-sign");
        //Deleted the extra ( in front of #
        WriteLine("#   pound sign or hash mark");
        //added a " after sign
        WriteLine("$   dollar sign");
    }
}

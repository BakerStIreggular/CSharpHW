﻿using static System.Console;
class GreenvilleMotto
{
    static void Main(string[] args)
    {
        WriteLine("The Stars Shine In Greenville");
    }
}

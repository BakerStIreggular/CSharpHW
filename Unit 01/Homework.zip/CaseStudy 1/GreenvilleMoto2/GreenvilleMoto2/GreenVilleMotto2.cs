﻿using static System.Console;
class GreenvilleMotto2
{
    static void Main(string[] args)
    {
        WriteLine("***********************************");
        WriteLine("*                                 *");
        WriteLine("*  The Stars Shine In Greenville  *");
        WriteLine("*                                 *");
        WriteLine("***********************************");
    }
}

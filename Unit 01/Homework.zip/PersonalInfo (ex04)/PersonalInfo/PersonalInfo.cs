﻿using System;
using static System.Console;
using System.Globalization;
class PersonalInfo
{
    static void Main(string[] args)
    {
        WriteLine("Name: Jessica Brown");
        WriteLine("Birthdate: January 31, 1988");
        WriteLine("Work Phone Number: (999)999-9999");
        WriteLine("Cell Phone Number: (888)888-8888");

    }
}


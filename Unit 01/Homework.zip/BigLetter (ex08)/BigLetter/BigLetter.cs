﻿using System;
using static System.Console;
using System.Globalization;
class BigLetter
{
    static void Main(string[] args)
    {


        WriteLine("IIIIIIII");
        WriteLine("   II   ");
        WriteLine("   II   ");
        WriteLine("   II   ");
        WriteLine("   II   ");
        WriteLine("   II   ");
        WriteLine("IIIIIIII");


    }
}

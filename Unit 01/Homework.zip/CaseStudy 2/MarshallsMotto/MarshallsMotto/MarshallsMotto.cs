﻿using static System.Console;
class MarshallsMotto
{
    static void Main(string[] args)
    {
        WriteLine("Make your vision your view");

    }
}

﻿using static System.Console;
class MarshallsMotto2
{
    static void Main(string[] args)
    {
        WriteLine("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
        WriteLine("M                              M");
        WriteLine("M  Make your vision your view  M");
        WriteLine("M                              M");
        WriteLine("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
    }
}

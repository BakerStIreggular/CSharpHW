﻿using System;
using static System.Console;
using System.Globalization;
class StopSign
{
    static void Main()
    {
        WriteLine("   XXXXXXX   ");
        WriteLine(" X         X");
        WriteLine("X    STOP   X");
        WriteLine(" X         X");
        WriteLine("   XXXXXXX   ");
        WriteLine("      X     ");
        WriteLine("      X     ");
        WriteLine("      X     ");
        WriteLine("      X     ");
    }
}

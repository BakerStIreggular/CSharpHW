﻿
using static System.Console;

//Corrected Spelling of Class
class DebugOne3
{
   //Corrected Spelling for Main
   static void Main()
   //moved Currly bracket for proper indentation  
   {
    WriteLine("This program lists the number 1 to 5 vertically");
    //added Line to write so each number appear on its own line
    WriteLine("1");
    WriteLine("2");
    WriteLine("3");
    WriteLine("4");
    WriteLine("5");
   //moved Currly bracket for proper indentation 
    }
}

﻿using System;
using static System.Console;
using System.Globalization;
class BurmaShave
{
    static void Main()
    {
        WriteLine("Cheer up face");
        WriteLine("The war is past");
        WriteLine("The \"H\" is out");
        WriteLine("Of shave");
        WriteLine("At last");
        WriteLine("Burma-Shave");
    }
}

﻿/*This program was written by Baker
 for C#.net
Spring 2025*/


using System;
using static System.Console;
using System.Globalization;
class Comments
{
    static void Main()
    {
        //This displays the definition of Program Comment
        WriteLine("A program comment is defined as a non-executing"+
            "statements that document a program");
    }
}

﻿using System;
using static System.Console;
using System.Globalization;
using System.Linq;
class Lyrics
{
    static void Main()
    {
        WriteLine("Song:Prophecy Artist: Taylor Swift");
        WriteLine("Hand on throttle");
        WriteLine("Thought I caught lightning in a bottle");
        WriteLine("Oh, but it's gone again");
        WriteLine("And it was written" +
            "I got cursed like Eve got bitten");
    }
}
